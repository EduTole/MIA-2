rm(list = ls())
setwd("D:/Dropbox/Docencia/UNI/L1/Aplicacion/Clean")
library(rio)
library(dplyr)
library(tidyverse)

data <- import ("BD2_Multiproducto_2021.dta")

data %>%  dim()
data %>%  names()

summary(data)

# Limpiamos informacion de NA
data <- data %>% 
  drop_na()

# Modelo Probit Ordenado
#install.packages("oglmx")
library(oglmx)
m0 <- oprobit.reg(rvida~1,data=data)
summary(m0)

m1 <- oprobit.reg(rvida~rsexo+ rpareja+ redad+redadsq+ reduca+rmu+
                    rly+ rmiembros ,data=data)
summary(m1)

# Efeto marginal
margins.oglmx(m1)


# Forma 2
m2_0 <- oglmx(rvida~1, data=data, link="probit", 
              constantMEAN = F, delta=0,threshparam=NULL)
summary(m2_0)

m2_1 <- oglmx(rvida~rsexo+ rpareja+ redad+redadsq+ reduca+rmu+
              rly+ rmiembros , data=data, link="probit", 
            constantMEAN = F, delta=0,threshparam=NULL)
summary(m2_1)
m2_1$coefficients
coef(m2_1)
# Efectos marginales
margins.oglmx(m2_1)
?margins.oglmx

#-------------------------------------------- #

attach(data)
table(data$rvida)
Y <- factor(data$rvida, levels=1:4,
            labels=c("Muy Mala","Mala","Buena", "Muy Buena"))
table(Y)

X<- cbind(rsexo, rpareja, redad,redadsq, reduca,rmu,
          rly, rmiembros)
#install.packages("MASS")
library(MASS)
m1 <- polr(Y ~ X, Hess = T)
summary(m1)

library(stargazer)
stargazer(m1, type="html", out="m1.htm")

# Modelos de probabilidad
m1.pred <- predict(m1, type="probs")
summary(m1.pred)

# Efectos marginales
#install.packages("erer")
library(erer)
ME <- ocME(w=m3)
ME <- ocME(w = m1.pred,rev.dum = T, digits = 3)
?ocME

library(MASS)
table(data$rvida)
summary(data)

data %>% str()

m1 <- polr(factor(rvida)~rsexo+ rpareja+ redad+redadsq+ reduca+rmu+
              rly+ rmiembros , data=data, method = "probit")
summary(m1)

#install.packages("oglmx")
library(oglmx)

data <- data %>% 
  mutate(y =factor(rvida, levels=1:4))
table(data$y)

m2 <- oglmx(rvida~rsexo+ rpareja+ redad+redadsq+ reduca+rmu+
              rly+ rmiembros , data=data, link="probit", 
            constantMEAN = F, delta=0,threshparam=NULL)

m3 <- oprobit.reg(rvida~rsexo+ rpareja+ redad+redadsq+ reduca+rmu+
                    rly+ rmiembros ,data=data)
summary(m2)
summary(m1)

# Efeto marginal
margins.oglmx(m3)
