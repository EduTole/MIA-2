rm(list = ls())
setwd("D:/Dropbox/Docencia/UNI/L1/Aplicacion/Clean")
library(rio)
library(dplyr)
library(tidyverse)

data <- import ("BD_Eleccion_2021.dta")

data %>%  dim()
data %>%  names()

summary(data)

estimacion <- data %>% 
  mutate(nivel_educa=factor(r2r_b, levels = 1:5)) %>% 
  drop_na()


# Modelo LOGIT- BINOMIAL
m1 <- glm(rpobre ~ ragua + rluz + lnr6 + nivel_educa + redad,
          family=binomial(link = "logit"), data=estimacion)
m1 <- glm(rpobre ~ ragua + rluz + lnr6 + nivel_educa + redad,
          family="binomial", data=estimacion)
summary(m1)

library(stargazer)
stargazer(m1, type = "html", out="Modelo_Logit.htm")

# Efecto Marginal
# Forma 1
library("margins")
margins(m1, type = "response")

#cplot(x, "wt", what = "prediction", main = "Predicted Fuel Economy, Given Weight")
# Forma 2
#install.packages("mfx")
library(mfx)
logitmfx(rpobre~ ragua + rluz + lnr6 + nivel_educa + redad,
         data=estimacion)

